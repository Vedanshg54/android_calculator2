package com.example.calculator;

import static java.lang.System.out;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
Button ADD,SUB,MUL,DIV;
EditText ip1,ip2;
TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ADD= findViewById(R.id.add);
        SUB= findViewById(R.id.sub);
        MUL= findViewById(R.id.mul);
        DIV= findViewById(R.id.div);
        ip1= findViewById(R.id.ip1);
        ip2 = findViewById(R.id.ip2);
        result= findViewById(R.id.result);

        ADD.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                int x = Integer.parseInt(ip1.getText().toString());
                int y = Integer.parseInt(ip2.getText().toString());
                int c = x + y;
                result.setText(" Addition is: "+c);
            }
        });

        SUB.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                int x = Integer.parseInt(ip1.getText().toString());
                int y = Integer.parseInt(ip2.getText().toString());
                int c = x - y;
                result.setText("Subtraction is: "+c);
            }
        });

        MUL.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                int x = Integer.parseInt(ip1.getText().toString());
                int y = Integer.parseInt(ip2.getText().toString());
                int c = x * y;
                result.setText("Multiplication is: "+c);
            }
        });

        DIV.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                int x = Integer.parseInt(ip1.getText().toString());
                int y = Integer.parseInt(ip2.getText().toString());
                int c = x / y;
                result.setText("Division is:4"+c);
            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}